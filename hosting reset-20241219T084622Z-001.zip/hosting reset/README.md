# reset-2022
Single page website to display Events, Conferences, Symposium, Sports details and registration using HTML, CSS and JavaScript
